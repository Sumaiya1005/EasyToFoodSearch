-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 25, 2024 at 07:08 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sumu-login`
--

-- --------------------------------------------------------

--
-- Table structure for table `sumu`
--

CREATE TABLE `sumu` (
  `Id.` int(4) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sumu`
--

INSERT INTO `sumu` (`Id.`, `firstname`, `lastname`, `email`, `phone`, `password`) VALUES
(1, 'sumaiya', 'shaid', 's@s.com', '12345678', 's@s.com'),
(2, 'sumau', 'shaid', 'sumu@12.com', '01855052928', '1234'),
(3, 'heelo', '1243', 'hello@gmail.com', '94082043918', '123242134'),
(4, 'Imranur Rahman', 'Sajid', 'test@gmail.com', '01791600299', '1234'),
(5, 'imran', 'Sajid', 'test2@gmail.com', '01791600299', '123123123'),
(6, 'Sumaiya', 'Shaid', 'test@3gmail.com', '0987654', 'test@3gmail.com'),
(7, 'imran', 'imran', 'imran@a.com', '1234567890', 'imran@a.com'),
(8, 'sumaiya', 'Sumaiya', 'Sumaiya@gmail.com', '123456789', 'Sumaiya@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sumu`
--
ALTER TABLE `sumu`
  ADD PRIMARY KEY (`Id.`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sumu`
--
ALTER TABLE `sumu`
  MODIFY `Id.` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
