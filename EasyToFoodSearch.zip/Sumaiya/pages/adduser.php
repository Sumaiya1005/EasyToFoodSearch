<?php
    $firstname = $_POST["firstname"]; 
    $lastname = $_POST["lastname"]; 
	$email = $_POST["email"]; 
	$phone = $_POST["phone"];
	$password = $_POST["password"];	
	

    $db =  mysqli_connect("127.0.0.1", "root" , "", "sumu-login");
	
	if ($db->connect_error) {
		echo "something wrong with datababse connection";
	}
	else{
		echo "succesfull";
	}
	 
	$x = "INSERT INTO sumu (firstname, lastname , email , phone , password ) VALUES 
	('$firstname', '$lastname','$email','$phone',  '$password')";
	 
	$db->query($x);
	header("Location:../index.php"); 

?>

