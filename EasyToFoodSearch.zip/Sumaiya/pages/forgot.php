<!doctype html>
<html lang="en">
  <head>
    <title>Forgot Password</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- google font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>

    <div class="oslab_wrapper oslab_forgot d-flex align-items-center justify-content-center">

        <div class="container">
            <div class="row mx-2 mx-md-0 shadow">
                <div class="col-md-8 col-lg-6  offset-md-2 offset-lg-0 p-0">
                    <div class="card oslab_right_card bg-white text-center px-4 py-5 rounded">
                        <div class="card-header bg-white border-0">
                            <h1>Forgot Password</h1>
                        </div>

                        <div class="card-body px-0 ">
                            <form class="form-validation" novalidate>
                                <div class="form-row">
                                    <div class="form-group col-md-12 text-left">
                                        <label for="inputEmail">Email Address</label>
                                        <input type="email" class="form-control" id="inputEmail" placeholder="Verify Email" required>
                                    </div>
                                </div>

                                <div class="oslab_forgot_pass mb-3 text-right">
                                    <a href="index.php">Back to login</a>
                                </div>
                                <button type="submit" class="btn btn-registration w-100 rounded">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-8 col-lg-6 d-none d-lg-block p-0">
                    <div class="card d-flex justify-content-center text-center oslab_left_card">
                        <div class="card-header">
                            <img class="w-100" src="asset/images/login.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
    </div>



  </body>
</html>